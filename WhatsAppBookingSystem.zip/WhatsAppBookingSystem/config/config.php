<?php

return [
    'name' => 'WhatsAppBookingSystem',
];
